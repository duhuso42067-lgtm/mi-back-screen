export type Token = { text: string; cls: string };

const KOTLIN_KEYWORDS = new Set(
  "package import class object interface fun val var if else when for while do return break continue is in as by get set private public protected internal override open abstract data enum companion init constructor const lateinit null true false this super try catch finally throw typealias suspend inline where out".split(
    " "
  )
);

type Rule = { re: RegExp; cls: string | ((m: string) => string) };

const kotlinRules: Rule[] = [
  { re: /\/\*[\s\S]*?\*\//y, cls: "text-slate-500 italic" },
  { re: /\/\/[^\n]*/y, cls: "text-slate-500 italic" },
  { re: /"""[\s\S]*?"""/y, cls: "text-emerald-300" },
  { re: /"(?:\\.|[^"\\\n])*"/y, cls: "text-emerald-300" },
  { re: /'(?:\\.|[^'\\\n])'/y, cls: "text-emerald-300" },
  { re: /@[A-Za-z_]+/y, cls: "text-amber-300" },
  { re: /\b0x[0-9A-Fa-f]+L?|\b\d[\d_]*(?:\.\d+)?[fFL]?\b/y, cls: "text-orange-300" },
  {
    re: /[A-Za-z_][A-Za-z0-9_]*/y,
    cls: (m) =>
      KOTLIN_KEYWORDS.has(m)
        ? "text-fuchsia-300"
        : /^[A-Z]/.test(m)
          ? "text-sky-300"
          : "",
  },
];

const xmlRules: Rule[] = [
  { re: /<!--[\s\S]*?-->/y, cls: "text-slate-500 italic" },
  { re: /"[^"]*"/y, cls: "text-emerald-300" },
  { re: /<\/?[A-Za-z_][\w.:-]*/y, cls: "text-sky-300" },
  { re: /\/?>/y, cls: "text-sky-300" },
  { re: /[A-Za-z_][\w.:-]*(?==)/y, cls: "text-amber-300" },
];

const yamlRules: Rule[] = [
  { re: /#[^\n]*/y, cls: "text-slate-500 italic" },
  { re: /"[^"\n]*"|'[^'\n]*'/y, cls: "text-emerald-300" },
  { re: /[A-Za-z_-][\w.-]*(?=:)/y, cls: "text-sky-300" },
  { re: /\b(?:true|false|null)\b/y, cls: "text-fuchsia-300" },
];

export function languageOf(path: string) {
  if (path.endsWith(".kt")) return "kotlin";
  if (path.endsWith(".xml")) return "xml";
  if (path.endsWith(".yml") || path.endsWith(".yaml")) return "yaml";
  return "text";
}

export function tokenize(code: string, lang: string): Token[] {
  const rules =
    lang === "kotlin" ? kotlinRules : lang === "xml" ? xmlRules : lang === "yaml" ? yamlRules : [];
  if (!rules.length) return [{ text: code, cls: "" }];
  const out: Token[] = [];
  let plain = "";
  let i = 0;
  const flush = () => {
    if (plain) out.push({ text: plain, cls: "" });
    plain = "";
  };
  while (i < code.length) {
    let hit = false;
    for (const rule of rules) {
      rule.re.lastIndex = i;
      const m = rule.re.exec(code);
      if (m && m.index === i && m[0].length > 0) {
        const cls = typeof rule.cls === "function" ? rule.cls(m[0]) : rule.cls;
        if (cls) {
          flush();
          out.push({ text: m[0], cls });
        } else {
          plain += m[0];
        }
        i += m[0].length;
        hit = true;
        break;
      }
    }
    if (!hit) {
      plain += code[i];
      i++;
    }
  }
  flush();
  return out;
}

/** Splits tokens into lines, so each line can be numbered. */
export function toLines(tokens: Token[]): Token[][] {
  const lines: Token[][] = [[]];
  for (const t of tokens) {
    const parts = t.text.split("\n");
    parts.forEach((part, idx) => {
      if (idx > 0) lines.push([]);
      if (part) lines[lines.length - 1].push({ text: part, cls: t.cls });
    });
  }
  if (lines.length > 1 && lines[lines.length - 1].length === 0) lines.pop();
  return lines;
}
