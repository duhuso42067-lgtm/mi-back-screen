import { useMemo, useState } from "react";
import bundle from "./bundle.json";
import { CodeViewer } from "./components/CodeViewer";
import { RearMock } from "./components/RearMock";

type FileEntry = { path: string; status: string; note: string; content: string };
const files = bundle.files as FileEntry[];
const patch = bundle.patch as string;

function save(blob: Blob, name: string) {
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 1000);
}

const short = (p: string) => p.replace("app/src/main/java/com/backscreen/wallpaper/", "…/");

function Badge({ children, tone }: { children: React.ReactNode; tone: "ok" | "new" | "mod" }) {
  const cls =
    tone === "ok"
      ? "bg-emerald-400/15 text-emerald-300 ring-emerald-400/30"
      : tone === "new"
        ? "bg-sky-400/15 text-sky-300 ring-sky-400/30"
        : "bg-amber-400/15 text-amber-300 ring-amber-400/30";
  return (
    <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ring-1 ${cls}`}>
      {children}
    </span>
  );
}

function Section({ id, title, kicker, children }: { id: string; title: string; kicker?: string; children: React.ReactNode }) {
  return (
    <section id={id} className="mx-auto w-full max-w-6xl scroll-mt-6 px-5 py-12">
      {kicker && <div className="mb-2 text-xs font-semibold uppercase tracking-[0.2em] text-sky-400">{kicker}</div>}
      <h2 className="mb-6 text-2xl font-bold tracking-tight text-white md:text-3xl">{title}</h2>
      {children}
    </section>
  );
}

export default function App() {
  const [selected, setSelected] = useState(files[0].path);
  const [zipping, setZipping] = useState(false);
  const [copiedAll, setCopiedAll] = useState(false);
  const current = files.find((f) => f.path === selected) ?? files[0];

  const counts = useMemo(
    () => ({
      news: files.filter((f) => f.status === "new").length,
      mods: files.filter((f) => f.status === "modified").length,
      lines: files.reduce((n, f) => n + f.content.split("\n").length, 0),
    }),
    []
  );

  const downloadZip = async () => {
    setZipping(true);
    try {
      const { default: JSZip } = await import("jszip");
      const zip = new JSZip();
      for (const f of files) zip.file(f.path, f.content);
      zip.file("media-player.patch", patch);
      save(await zip.generateAsync({ type: "blob" }), "mi-back-screen-media-player.zip");
    } finally {
      setZipping(false);
    }
  };

  const copyAll = async () => {
    const text = files.map((f) => `// ===== ${f.path} (${f.status}) =====\n${f.content}`).join("\n\n");
    await navigator.clipboard.writeText(text).catch(() => {});
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 1800);
  };

  return (
    <div className="min-h-screen bg-[#070a11] text-slate-300 antialiased">
      {/* hero */}
      <header className="relative overflow-hidden border-b border-white/10">
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(60% 80% at 75% 120%, rgba(30,90,255,.55), transparent 60%), radial-gradient(40% 60% at 10% -10%, rgba(80,120,255,.18), transparent 70%)",
          }}
        />
        <div className="relative mx-auto max-w-6xl px-5 pb-16 pt-14">
          <div className="mb-4 flex flex-wrap gap-2">
            <Badge tone="ok">assembleDebug ✓</Badge>
            <Badge tone="ok">unit tests ✓</Badge>
            <Badge tone="ok">lintDebug ✓</Badge>
            <Badge tone="ok">patch applies to main ✓</Badge>
          </div>
          <h1 className="max-w-3xl text-4xl font-extrabold leading-tight tracking-tight text-white md:text-6xl">
            Xiaomi-style rear media player for <span className="text-sky-400">mi-back-screen</span>
          </h1>
          <p className="mt-5 max-w-2xl text-lg leading-relaxed text-slate-300">
            Any media app, right in the rear-screen wallpaper window. It reuses the app's notification listener, follows the
            lit and dimmed states, keeps swipe-left for the camera, and adds swipe up or right to flip between wallpaper and player.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              onClick={downloadZip}
              disabled={zipping}
              className="rounded-xl bg-sky-400 px-5 py-3 text-sm font-bold text-sky-950 shadow-lg shadow-sky-500/20 transition hover:bg-sky-300 disabled:opacity-60"
            >
              {zipping ? "Packing…" : `⬇ Download all ${files.length} files (.zip)`}
            </button>
            <button
              onClick={() => save(new Blob([patch], { type: "text/x-patch" }), "media-player.patch")}
              className="rounded-xl border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-white transition hover:bg-white/10"
            >
              ⬇ media-player.patch
            </button>
            <a href="#files" className="rounded-xl px-4 py-3 text-sm font-semibold text-sky-300 transition hover:text-sky-200">
              Browse the code ↓
            </a>
          </div>
          <div className="mt-10 grid max-w-2xl grid-cols-3 gap-4 text-center">
            {[
              [counts.news, "new files"],
              [counts.mods, "modified files"],
              [counts.lines.toLocaleString(), "lines, in full"],
            ].map(([n, l]) => (
              <div key={l as string} className="rounded-xl border border-white/10 bg-white/[0.04] px-4 py-4 backdrop-blur">
                <div className="text-2xl font-bold text-white">{n}</div>
                <div className="text-xs uppercase tracking-wider text-slate-400">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </header>

      {/* preview */}
      <Section id="preview" kicker="Target" title="The two looks you photographed">
        <p className="mb-6 max-w-3xl text-slate-400">
          A CSS model of the 976 × 596 panel built from the same fractions <code className="text-sky-300">MediaPlayerLayer</code> uses.
          Lit (photo 1) is left-aligned with the buttons and indicator bar; dimmed (photo 2) is centred, lower, button-less, with the glow and clock pill dimmed.
        </p>
        <RearMock />
      </Section>

      {/* apply */}
      <Section id="apply" kicker="Install" title="Get it into your fork">
        <div className="grid gap-4 md:grid-cols-3">
          {[
            {
              t: "A · git apply",
              b: "Fastest. In your fork's root:",
              c: 'git apply --check media-player.patch\ngit apply media-player.patch\ngit add -A && git commit -m "Rear media player"\ngit push',
            },
            {
              t: "B · unzip over the repo",
              b: "The zip keeps repo paths, so extract it into your fork's root and overwrite the 6 modified files:",
              c: 'unzip -o mi-back-screen-media-player.zip -d .\ngit add -A && git commit -m "Rear media player"\ngit push',
            },
            {
              t: "C · paste by hand",
              b: "Every file is below in full, with Copy file buttons. New files go in the same folders shown in their path.",
              c: '# No placeholders and no\n# "existing code" comments anywhere.',
            },
          ].map((s) => (
            <div key={s.t} className="rounded-xl border border-white/10 bg-white/[0.03] p-5">
              <div className="mb-2 font-semibold text-white">{s.t}</div>
              <p className="mb-3 text-sm text-slate-400">{s.b}</p>
              <pre className="overflow-x-auto rounded-lg bg-black/50 p-3 text-xs leading-relaxed text-emerald-300">{s.c}</pre>
            </div>
          ))}
        </div>
        <p className="mt-5 text-sm text-slate-400">
          After the first push, <code className="text-sky-300">build.yml</code> compiles the APK: Actions tab → the run →
          <span className="text-white"> Artifacts → mi-back-screen-debug-apk</span>.
        </p>
      </Section>

      {/* files */}
      <Section id="files" kicker="Code" title="Every file, complete">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <p className="text-sm text-slate-400">Pick a file; the full source is on the right.</p>
          <button
            onClick={copyAll}
            className="rounded-lg border border-white/15 bg-white/5 px-3 py-1.5 text-xs font-semibold text-white transition hover:bg-white/10"
          >
            {copiedAll ? "Copied all ✓" : "Copy everything"}
          </button>
        </div>
        <div className="grid gap-5 lg:grid-cols-[340px_1fr]">
          <nav className="max-h-[78vh] space-y-1 overflow-auto rounded-xl border border-white/10 bg-white/[0.03] p-2">
            {files.map((f) => {
              const active = f.path === current.path;
              return (
                <button
                  key={f.path}
                  onClick={() => setSelected(f.path)}
                  className={`block w-full rounded-lg px-3 py-2 text-left transition ${
                    active ? "bg-sky-400/15 ring-1 ring-sky-400/40" : "hover:bg-white/5"
                  }`}
                >
                  <div className="mb-1 flex items-center gap-2">
                    <Badge tone={f.status === "new" ? "new" : "mod"}>{f.status === "new" ? "new" : "modified"}</Badge>
                    <span className="truncate text-sm font-semibold text-white">{f.path.split("/").pop()}</span>
                  </div>
                  <div className="truncate text-[11px] text-slate-500">{short(f.path)}</div>
                </button>
              );
            })}
          </nav>
          <div className="min-w-0">
            <div className="mb-3 flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-4">
              <Badge tone={current.status === "new" ? "new" : "mod"}>{current.status === "new" ? "new" : "modified"}</Badge>
              <p className="text-sm leading-relaxed text-slate-300">{current.note}</p>
            </div>
            <CodeViewer key={current.path} path={current.path} content={current.content} />
          </div>
        </div>
      </Section>

      {/* how */}
      <Section id="how" kicker="Design" title="How each requirement is met">
        <div className="grid gap-4 md:grid-cols-2">
          {[
            {
              t: "1 · Media session tracking",
              b: "RearNotificationListener hands its own ComponentName to MediaTracker, which calls MediaSessionManager.getActiveSessions(component) and registers for session changes. It prefers a playing session, then the last one shown. Title, artist and art (bitmap, or a content/file URI loaded off the main thread) come from the metadata; previous, play/pause and next go through transportControls. The listener now stays bound while the player is on, even with Notifications off.",
            },
            {
              t: "2 · The UI",
              b: "MediaPlayerLayer is one ViewGroup laid out in fractions of the panel, to the right of the camera insets: black base, glow from Palette's most vibrant colour (system accent for grey art, as in your photos), clock pill top-right, rounded-square art, bold title, muted artist.",
            },
            {
              t: "3 · Lit vs dimmed",
              b: "RearHostActivity.onRearStateChanged calls setLit(). Lit: buttons and bar visible, glow and pill bright, left-aligned. Dimmed: buttons and bar GONE, art/title/artist centred and lower, glow and pill dimmed, applied instantly and pushed to the panel with the app's existing draw-wake-lock path, since a dimmed panel shows no animation. The minute alarm now also runs for the pill.",
            },
            {
              t: "4 · Gestures and switching",
              b: "Swipe left for the camera is untouched. Swipe up or right (RearGestures + Swipes.classifyMedia, kept apart so the existing swipe tests hold) toggles wallpaper and player while lit. When music starts, the window switches by itself if the toggle is on, and falls back to the wallpaper when no session is left. Wallpaper panning pauses underneath to save battery.",
            },
          ].map((c) => (
            <div key={c.t} className="rounded-xl border border-white/10 bg-white/[0.03] p-5">
              <h3 className="mb-2 font-semibold text-white">{c.t}</h3>
              <p className="text-sm leading-relaxed text-slate-400">{c.b}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 rounded-xl border border-amber-400/25 bg-amber-400/[0.06] p-5">
          <h3 className="mb-3 font-semibold text-amber-200">Decisions worth knowing</h3>
          <ul className="list-disc space-y-2 pl-5 text-sm leading-relaxed text-slate-300">
            <li>
              <b className="text-white">Your photos disagree with the brief on alignment.</b> In photo 1 (lit) the art, title and artist are left-aligned to the art; in photo 2 (dimmed) they are centred. I followed the photos. To centre both, make the lit target in <code className="text-sky-300">MediaPlayerLayer.onLayout</code> the centred value instead of <code className="text-sky-300">zoneL</code>.
            </li>
            <li>
              <b className="text-white">The toggle is a dialog in the top-bar menu</b> (“Media player”), not a sixth tab: Material's bottom navigation allows at most five items and the app already has five.
            </li>
            <li>
              The player lives in the wallpaper's window, so <b className="text-white">Show on back screen must be on</b>; the dialog warns if it isn't.
            </li>
            <li>
              Notification access is the same grant the Notifications tab uses; the dialog has an Allow access button (Shizuku, with a Settings fallback). Web-hosted album art is skipped because the app has no INTERNET permission, so apps that give only an https URL show the glow without art.
            </li>
            <li>
              Checked in a sandbox: <code className="text-sky-300">assembleDebug</code>, <code className="text-sky-300">testDebugUnitTest</code> and <code className="text-sky-300">lintDebug</code> pass. I have no Xiaomi 17 Pro Max, so the sizes (shares of the 596 px height, read off your photos) and the dimmed-panel frame pushes are untested on hardware. All the tuning constants are at the bottom of <code className="text-sky-300">MediaPlayerLayer</code>.
            </li>
          </ul>
        </div>
      </Section>

      <footer className="border-t border-white/10 px-5 py-8 text-center text-xs text-slate-500">
        Based on totallynotkasai/mi-back-screen (MIT). Not affiliated with Xiaomi.
      </footer>
    </div>
  );
}
