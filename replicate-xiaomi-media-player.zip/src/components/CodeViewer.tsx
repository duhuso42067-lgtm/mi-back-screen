import { memo, useMemo, useState } from "react";
import { languageOf, toLines, tokenize } from "../highlight";

type Props = { path: string; content: string };

function CodeViewerImpl({ path, content }: Props) {
  const [copied, setCopied] = useState(false);
  const lines = useMemo(
    () => toLines(tokenize(content, languageOf(path))),
    [content, path]
  );
  const gutter = String(lines.length).length;

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(content);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = content;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      ta.remove();
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  };

  const download = () => {
    const blob = new Blob([content], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = path.split("/").pop() ?? "file.txt";
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <div className="overflow-hidden rounded-xl border border-white/10 bg-[#0b0f17]">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 bg-white/[0.03] px-4 py-2.5">
        <code className="break-all text-xs text-slate-300">{path}</code>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500">{lines.length} lines</span>
          <button
            onClick={download}
            className="rounded-md border border-white/10 px-2.5 py-1 text-xs text-slate-300 transition hover:bg-white/10"
          >
            Download
          </button>
          <button
            onClick={copy}
            className={`rounded-md px-3 py-1 text-xs font-semibold transition ${
              copied
                ? "bg-emerald-400 text-emerald-950"
                : "bg-sky-400 text-sky-950 hover:bg-sky-300"
            }`}
          >
            {copied ? "Copied ✓" : "Copy file"}
          </button>
        </div>
      </div>
      <div className="max-h-[70vh] overflow-auto">
        <pre className="min-w-max py-3 text-[12.5px] leading-[1.55] text-slate-200">
          {lines.map((line, i) => (
            <div key={i} className="flex">
              <span
                className="sticky left-0 select-none bg-[#0b0f17] pl-4 pr-3 text-right text-slate-600"
                style={{ minWidth: `${gutter + 3}ch` }}
              >
                {i + 1}
              </span>
              <code className="pr-6 whitespace-pre">
                {line.length === 0
                  ? " "
                  : line.map((t, j) => (
                      <span key={j} className={t.cls}>
                        {t.text}
                      </span>
                    ))}
              </code>
            </div>
          ))}
        </pre>
      </div>
    </div>
  );
}

export const CodeViewer = memo(CodeViewerImpl);
