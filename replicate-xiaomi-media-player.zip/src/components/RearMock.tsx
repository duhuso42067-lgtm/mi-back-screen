import { useState } from "react";

type Props = { lit: boolean; hue: number };

/** A CSS model of the 976 x 596 rear panel, using the same shares as MediaPlayerLayer. */
function Panel({ lit, hue }: Props) {
  const zoneL = 36;
  const zoneC = 65.5;
  const bright = `hsl(${hue} 90% 62%)`;
  const mid = `hsl(${hue} 90% 43%)`;
  const top = `hsl(${hue} 90% 28%)`;

  const ease = "all 450ms cubic-bezier(.3,.7,.2,1)";
  const textX = lit ? zoneL : zoneC;
  const textT = lit ? "translate(0,-50%)" : "translate(-50%,-50%)";

  const icon = (d: string, size: number, left: number, extra = "") => (
    <svg
      viewBox="0 0 24 24"
      className="absolute"
      style={{
        height: `${size}cqh`,
        width: `${size}cqh`,
        left: `${left}%`,
        top: "77.5%",
        transform: "translate(-50%,-50%)",
        opacity: lit ? 1 : 0,
        transition: ease,
      }}
      fill="white"
      stroke="white"
      strokeLinejoin="round"
      strokeLinecap="round"
    >
      <path d={d} strokeWidth={extra ? 3.4 : 1.2} fill={extra ? "none" : "white"} />
    </svg>
  );

  return (
    <div
      className="relative w-full overflow-hidden rounded-[9%/15%] bg-black ring-1 ring-white/15"
      style={{ aspectRatio: "976 / 596", containerType: "size" }}
    >
      {/* glow */}
      <div
        className="absolute inset-0"
        style={{
          background: `linear-gradient(200deg, ${top}, ${mid})`,
          opacity: lit ? 1 : 0.4,
          transition: ease,
        }}
      />
      <div
        className="absolute inset-0"
        style={{
          background: `radial-gradient(ellipse 62% 70% at 55% 108%, ${bright}, ${bright}55 55%, transparent)`,
          opacity: lit ? 0.85 : 0.34,
          transition: ease,
        }}
      />

      {/* cameras */}
      <div className="absolute rounded-full bg-black ring-[0.8cqh] ring-zinc-700" style={{ left: "3.5%", top: "7%", width: "36cqh", height: "36cqh" }}>
        <div className="absolute inset-[22%] rounded-full bg-gradient-to-br from-zinc-800 to-black ring-1 ring-sky-900/60" />
      </div>
      <div className="absolute rounded-full bg-black ring-[0.8cqh] ring-zinc-700" style={{ left: "5.5%", top: "50%", width: "40cqh", height: "40cqh" }}>
        <div className="absolute inset-[22%] rounded-full bg-gradient-to-br from-zinc-800 to-black ring-1 ring-sky-900/60" />
      </div>

      {/* pill */}
      <div
        className="absolute font-bold text-white"
        style={{
          right: "5.5%",
          top: "6.5%",
          fontSize: "4.2cqh",
          padding: "1.2cqh 2.4cqw",
          borderRadius: 999,
          background: `color-mix(in srgb, ${bright} ${lit ? 92 : 37}%, transparent)`,
          transition: ease,
          lineHeight: 1.1,
        }}
      >
        17:49
      </div>

      {/* art */}
      <div
        className="absolute overflow-hidden"
        style={{
          left: `${lit ? zoneL : zoneC}%`,
          top: `${lit ? 12.5 : 25.5}cqh`,
          height: `${lit ? 30.5 : 27}cqh`,
          width: `${lit ? 30.5 : 27}cqh`,
          transform: lit ? "none" : "translateX(-50%)",
          borderRadius: "20%",
          background:
            "repeating-linear-gradient(135deg,#d4d4d8 0 6px,#52525b 6px 12px), #888",
          filter: "grayscale(1)",
          transition: ease,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-b from-white/40 via-transparent to-black/60" />
        <div className="absolute bottom-[6%] left-[8%] right-[8%] text-center text-[3.2cqh] font-black tracking-tight text-white">
          ALBUM
        </div>
      </div>

      {/* title + artist */}
      <div
        className="absolute whitespace-nowrap font-bold text-white"
        style={{
          left: `${textX}%`,
          top: `${lit ? 53.5 : 64.5}%`,
          transform: textT,
          fontSize: "7.7cqh",
          lineHeight: 1,
          transition: ease,
        }}
      >
        Brooklyn Baby
      </div>
      <div
        className="absolute whitespace-nowrap text-white/80"
        style={{
          left: `${textX}%`,
          top: `${lit ? 64.5 : 74.5}%`,
          transform: textT,
          fontSize: "6cqh",
          lineHeight: 1,
          transition: ease,
        }}
      >
        Lana Del Rey
      </div>

      {/* controls */}
      {icon("M5.5,5.5h2.4v13h-2.4z M19.2,6.6v10.8L10,12z", 8.8, 46.1)}
      {icon("M8.6,5.8L8.6,18.2 M15.4,5.8L15.4,18.2", 12.6, 65.5, "bars")}
      {icon("M16.1,5.5h2.4v13h-2.4z M4.8,6.6v10.8L14,12z", 8.8, 84.9)}

      {/* bar */}
      <div
        className="absolute rounded-full bg-white/90"
        style={{
          left: "65.5%",
          top: "94%",
          width: "6.5%",
          height: "1.1cqh",
          transform: "translate(-50%,-50%)",
          opacity: lit ? 1 : 0,
          transition: ease,
        }}
      />
    </div>
  );
}

export function RearMock() {
  const [hue, setHue] = useState(226);
  const [lit, setLit] = useState(true);
  const swatches = [
    { h: 226, n: "Blue (grey art → accent)" },
    { h: 4, n: "Red" },
    { h: 32, n: "Orange" },
    { h: 140, n: "Green" },
    { h: 285, n: "Purple" },
    { h: 330, n: "Pink" },
  ];
  return (
    <div>
      <div className="grid gap-5 md:grid-cols-2">
        <div>
          <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-sky-300">
            <span className="h-2 w-2 rounded-full bg-sky-300" /> Lit · photo 1
          </div>
          <Panel lit hue={hue} />
        </div>
        <div>
          <div className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
            <span className="h-2 w-2 rounded-full bg-slate-500" /> Dimmed / AOD · photo 2
          </div>
          <Panel lit={false} hue={hue} />
        </div>
      </div>

      <div className="mt-6 grid items-center gap-5 rounded-xl border border-white/10 bg-white/[0.03] p-4 md:grid-cols-[1fr_auto]">
        <div>
          <div className="mb-2 text-xs text-slate-400">
            Live morph (what <code className="text-sky-300">setLit()</code> does when the rear wakes) and accent colour taken from the album art:
          </div>
          <div className="flex flex-wrap gap-2">
            {swatches.map((s) => (
              <button
                key={s.h}
                title={s.n}
                onClick={() => setHue(s.h)}
                className={`h-7 w-7 rounded-full ring-2 transition ${hue === s.h ? "ring-white" : "ring-transparent hover:ring-white/40"}`}
                style={{ background: `hsl(${s.h} 90% 50%)` }}
              />
            ))}
          </div>
        </div>
        <button
          onClick={() => setLit((v) => !v)}
          className="rounded-lg bg-white/10 px-4 py-2 text-sm font-medium text-white transition hover:bg-white/20"
        >
          {lit ? "Dim the panel" : "Light the panel"}
        </button>
      </div>
      <div className="mx-auto mt-5 max-w-xl">
        <Panel lit={lit} hue={hue} />
      </div>
    </div>
  );
}
